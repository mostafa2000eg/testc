#!/bin/bash
cd "$(dirname "$0")"
echo "🧪 اختبار النظام..."
python3 test_enhanced_system.py
read -p "اضغط Enter للمتابعة..."
